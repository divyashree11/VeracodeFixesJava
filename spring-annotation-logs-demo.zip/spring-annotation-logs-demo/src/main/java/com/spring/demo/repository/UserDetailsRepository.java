package com.spring.demo.repository;

import com.spring.demo.model.User;

public interface UserDetailsRepository {
	public String createUSer(User user);

}
